# JL-Mod Plus — Complete 39-Locale Modular Localization Package

## Summary
- **Total locales**: 39 (`values/` English default + 38 translated `values-*` folders).
- **Structure**: 9 modular XML files in `values/` (including `strings_untranslatable.xml`) and 8 matching modular XML files in each of the 38 translated `values-*` folders (313 XML files total).
- **Coverage**: 100% parity across all 39 locales — 1,490 translatable strings + 34 `<plurals>` per translated locale (1,523 strings + 34 `<plurals>` in English default), translated freshly from the code-verified English v2 base.
- **Validation**: 0 XML errors, 0 missing/extra/duplicate keys, 0 format-specifier or `<xliff:g>` mismatches, 0 broken UTF-8 characters.

## Drop-In Migration Steps
1. Remove all legacy monolithic `strings.xml` (and old `strings_rendering.xml`) files from `app/src/main/res/values*`:
   ```bash
   rm -f app/src/main/res/values/strings.xml app/src/main/res/values/strings_rendering.xml
   rm -f app/src/main/res/values-*/strings.xml app/src/main/res/values-*/strings_rendering.xml
   ```
2. Extract `app/src/main/res/` from this archive directly into your repository root.
3. No Kotlin or Java code changes are required (`R.string.*` and `R.plurals.*` keys are 100% preserved).
4. Optional CI check: run `python3 scripts/validate_locale.py app/src/main/res/values-<locale>` whenever adding or updating strings.

## Validated Locale Matrix
| Locale Folder | Strings | Plurals | CLDR Plural Quantities |
| :--- | :---: | :---: | :--- |
| `values/` (English default) | 1,523 (33 untranslatable) | 34 | `one, other` |
| `values-af/` | 1,490 | 34 | `one, other` |
| `values-ar/` | 1,490 | 34 | `few, many, one, other, two, zero` |
| `values-bg/` | 1,490 | 34 | `one, other` |
| `values-bn/` | 1,490 | 34 | `one, other` |
| `values-ca/` | 1,490 | 34 | `many, one, other` |
| `values-cs/` | 1,490 | 34 | `few, many, one, other` |
| `values-da/` | 1,490 | 34 | `one, other` |
| `values-de/` | 1,490 | 34 | `one, other` |
| `values-el/` | 1,490 | 34 | `one, other` |
| `values-es/` | 1,490 | 34 | `many, one, other` |
| `values-fa/` | 1,490 | 34 | `one, other` |
| `values-fi/` | 1,490 | 34 | `one, other` |
| `values-fr/` | 1,490 | 34 | `many, one, other` |
| `values-hi/` | 1,490 | 34 | `one, other` |
| `values-hu/` | 1,490 | 34 | `one, other` |
| `values-in/` | 1,490 | 34 | `other` |
| `values-it/` | 1,490 | 34 | `many, one, other` |
| `values-iw/` | 1,490 | 34 | `one, other, two` |
| `values-ja/` | 1,490 | 34 | `other` |
| `values-kk/` | 1,490 | 34 | `one, other` |
| `values-ko/` | 1,490 | 34 | `other` |
| `values-nl/` | 1,490 | 34 | `one, other` |
| `values-no/` | 1,490 | 34 | `one, other` |
| `values-or/` | 1,490 | 34 | `one, other` |
| `values-pl/` | 1,490 | 34 | `few, many, one, other` |
| `values-pt/` | 1,490 | 34 | `many, one, other` |
| `values-pt-rBR/` | 1,490 | 34 | `many, one, other` |
| `values-ro/` | 1,490 | 34 | `few, one, other` |
| `values-ru/` | 1,490 | 34 | `few, many, one, other` |
| `values-si/` | 1,490 | 34 | `one, other` |
| `values-sr/` | 1,490 | 34 | `few, one, other` |
| `values-sv/` | 1,490 | 34 | `one, other` |
| `values-th/` | 1,490 | 34 | `other` |
| `values-tr/` | 1,490 | 34 | `one, other` |
| `values-uk/` | 1,490 | 34 | `few, many, one, other` |
| `values-vi/` | 1,490 | 34 | `other` |
| `values-zh-rCN/` | 1,490 | 34 | `other` |
| `values-zh-rTW/` | 1,490 | 34 | `other` |
