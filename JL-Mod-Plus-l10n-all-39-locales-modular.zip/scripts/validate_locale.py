import sys, os, re, glob, xml.etree.ElementTree as ET

PLACEHOLDER_RE = re.compile(r'%(?:(\d+)\$)?([sdif])')
EXPECTED_FILES = [
    "strings_common.xml",
    "strings_config.xml",
    "strings_controls.xml",
    "strings_library.xml",
    "strings_memory.xml",
    "strings_rendering.xml",
    "strings_runtime.xml",
    "strings_settings.xml",
]

def load_dir(d, skip_untranslatable=False):
    strings, plurals, dups = {}, {}, []
    for fn in EXPECTED_FILES:
        p = os.path.join(d, fn)
        if not os.path.exists(p):
            raise FileNotFoundError(f"Missing required file: {p}")
        root = ET.parse(p).getroot()
        for ch in root:
            name = ch.attrib["name"]
            if ch.tag == "string":
                if skip_untranslatable and ch.attrib.get("translatable") == "false":
                    continue
                if name in strings:
                    dups.append((fn, name))
                strings[name] = (fn, "".join(ch.itertext()))
            elif ch.tag == "plurals":
                if name in plurals:
                    dups.append((fn, name))
                plurals[name] = (fn, {it.attrib["quantity"]: "".join(it.itertext()) for it in ch})
    return strings, plurals, dups

def main():
    if len(sys.argv) != 2:
        print("Usage: python3 validate_locale.py <locale_dir>")
        sys.exit(2)
    en_dir = "/working_dir/c_5211171c76c14896/work_en/output_values_v2"
    loc_dir = sys.argv[1]

    # Ensure strings_untranslatable.xml is NOT copied to locale dir
    if os.path.exists(os.path.join(loc_dir, "strings_untranslatable.xml")):
        print("FAIL: strings_untranslatable.xml must NOT exist in locale directory!")
        sys.exit(1)

    en_s, en_p, _ = load_dir(en_dir, skip_untranslatable=True)
    loc_s, loc_p, loc_dups = load_dir(loc_dir, skip_untranslatable=False)

    errors = []
    if loc_dups:
        errors.append(f"Duplicate keys: {loc_dups[:10]}")

    missing_s = sorted(set(en_s) - set(loc_s))
    extra_s = sorted(set(loc_s) - set(en_s))
    if missing_s:
        errors.append(f"Missing {len(missing_s)} string keys, e.g. {missing_s[:10]}")
    if extra_s:
        errors.append(f"Extra {len(extra_s)} string keys, e.g. {extra_s[:10]}")

    missing_p = sorted(set(en_p) - set(loc_p))
    extra_p = sorted(set(loc_p) - set(en_p))
    if missing_p:
        errors.append(f"Missing {len(missing_p)} plurals keys, e.g. {missing_p[:10]}")
    if extra_p:
        errors.append(f"Extra {len(extra_p)} plurals keys, e.g. {extra_p[:10]}")

    for k in sorted(set(en_s) & set(loc_s)):
        efn, eval_ = en_s[k]
        lfn, lval = loc_s[k]
        if efn != lfn:
            errors.append(f"Key {k} in wrong file: expected {efn}, got {lfn}")
        if not lval.strip():
            errors.append(f"Empty translation for {k}")
        if sorted(PLACEHOLDER_RE.findall(eval_)) != sorted(PLACEHOLDER_RE.findall(lval)):
            errors.append(f"Placeholder mismatch on {k}: EN={PLACEHOLDER_RE.findall(eval_)} vs LOC={PLACEHOLDER_RE.findall(lval)}")
        if "\n" in lval:
            errors.append(f"Literal newline inside string {k}")
        if eval_.count("\\n") != lval.count("\\n"):
            errors.append(f"\\n count mismatch on {k}: EN={eval_.count(chr(92)+'n')} vs LOC={lval.count(chr(92)+'n')}")

    for k in sorted(set(en_p) & set(loc_p)):
        efn, emap = en_p[k]
        lfn, lmap = loc_p[k]
        if efn != lfn:
            errors.append(f"Plural {k} in wrong file: expected {efn}, got {lfn}")
        if "other" not in lmap:
            errors.append(f"Plural {k} missing quantity='other'")
        e_other = emap["other"]
        for q, lval in lmap.items():
            if not lval.strip():
                errors.append(f"Empty plural translation for {k}[{q}]")
            if sorted(PLACEHOLDER_RE.findall(e_other)) != sorted(PLACEHOLDER_RE.findall(lval)):
                errors.append(f"Placeholder mismatch on plural {k}[{q}]")
            if "\n" in lval:
                errors.append(f"Literal newline inside plural {k}[{q}]")

    if errors:
        print(f"FAIL ({len(errors)} errors):")
        for e in errors[:30]:
            print("  -", e)
        sys.exit(1)
    print(f"PASS: {loc_dir} validated — {len(loc_s)} strings + {len(loc_p)} plurals across 8 modular files (100% parity, 0 errors).")

if __name__ == "__main__":
    main()
