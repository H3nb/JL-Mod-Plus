# JL-Mod Plus — PR #162 reviewed screenshot references

Source: Android CI #38155639367, PR head 045f7446021f9ff0573f2bf59df2fc96941294e5, base 0a57d5dfba660a03f124fcdbba40f6ec1071590e.

All eight images are original renderer outputs from the same CI run. Four existing references are replaced; four missing About/Donation references are added. Their filenames, PNG byte hashes and source provenance are in `provenance.json`.

## Apply to PR branch

1. Check out `fix/manual-display-scaling` at its reviewed HEAD.
2. Unzip this archive outside the repository and run:

```bash
git rev-parse HEAD  # must be 045f7446021f9ff0573f2bf59df2fc96941294e5
git apply --check /path/to/pr162-all-reviewed-screenshot-baselines.patch
git apply /path/to/pr162-all-reviewed-screenshot-baselines.patch
git add app/src/screenshotTestEmulatorDebug/reference/
git diff --cached --stat
git commit -m "test(screenshot): update reviewed Config and Library references"
git push origin fix/manual-display-scaling
```

3. Re-run normal PR CI, confirm the screenshot job succeeds and review the updated comparison report before merging.

This is the documented local binary-patch mechanism from `docs/development.md`. The owner-only `/jlmod-promote-screenshots` mechanism **cannot** consume this CI artifact because it excludes four missing-reference failures; do not bypass that guard.

Known screenshot-renderer limitation: previews labeled Indonesian currently render English, as documented in `LibraryProfilesScreenshotTest.kt`; those snapshots do not validate app locale quality. The actual rendered PNG bytes are preserved exactly.
